#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试OptimalFocalCal_ui.py的UI加载
"""

import sys
import os

# 添加当前目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# 模拟缺失的模块
try:
    import ChipPositionShow
except ImportError:
    # 模拟ChipPositionShow模块
    class MockChipPositionShow:
        class WaferViewer:
            def __init__(self, *args, **kwargs):
                pass
            
            def setAttribute(self, *args, **kwargs):
                pass
            
            def show(self):
                pass
            
            def close(self):
                pass
            
            def isVisible(self):
                return False
            
            @property
            def destroyed(self):
                class MockSignal:
                    def connect(self, *args, **kwargs):
                        pass
                return MockSignal()
            
            @property
            def sig_selected_points(self):
                class MockSignal:
                    def connect(self, *args, **kwargs):
                        pass
                return MockSignal()
            
            @property
            def sig_move_to_mark_position(self):
                class MockSignal:
                    def connect(self, *args, **kwargs):
                        pass
                return MockSignal()
    
    class MockChipPositionShowModule:
        WaferViewer = MockChipPositionShow.WaferViewer
    
    sys.modules['ChipPositionShow'] = MockChipPositionShowModule()
    import ChipPositionShow

# 模拟AlgorithmServer模块
try:
    from AlgorithmServer.common_algorithm import create_chip_position, ega_nominal_list_to_real
except ImportError:
    # 模拟算法函数
    def create_chip_position(wafer_radius, chip_width, chip_height, spacing):
        return []
    
    def ega_nominal_list_to_real(chip_list, ega_param):
        return []
    
    # 添加到全局命名空间
    globals()['create_chip_position'] = create_chip_position
    globals()['ega_nominal_list_to_real'] = ega_nominal_list_to_real

from PyQt5.QtWidgets import QApplication
from OptimalFocalCal_ui import Ui_Widget


def test_optimal_focal_ui():
    """测试OptimalFocalCal UI加载"""
    print("测试OptimalFocalCal UI加载...")
    
    app = QApplication(sys.argv)
    
    # 创建主窗口
    widget = Ui_Widget()
    widget.setupUi(widget)
    
    # 显示窗口
    widget.show()
    
    # 运行应用
    print("OptimalFocalCal UI加载成功！")
    print("窗口已显示，按Ctrl+C退出测试")
    
    try:
        sys.exit(app.exec_())
    except KeyboardInterrupt:
        print("测试结束")


if __name__ == "__main__":
    test_optimal_focal_ui()
