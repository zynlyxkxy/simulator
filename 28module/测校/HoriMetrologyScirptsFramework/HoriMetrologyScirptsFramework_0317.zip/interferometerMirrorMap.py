# -*- coding: utf-8 -*-
"""
Filename: AlignStabilityDynamic.py
Date: 2025/9/1
Description:
    干涉仪mirror map
"""
import time

from metrology_config import MetrologyConfig
from ScriptWidget import ScriptWidget
from cmdjson.PahoMqttClient import PahoMqttClient
from cmdjson.MC_Motion_cmd import LST_AXIS_NAME
from MqttReceiveWorker import MqttReceiveWorker
import cmdjson.MC_Motion_cmd as mcmotion
import cmdjson.Camera_CMD as mcCamera
import interferometerMirrorMap_ui as ui
from MirrorTextX import calculate_y_mirror
from MirrorTextY import calculate_x_mirror
from plc_grpc_client import PlcClient

from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from PyQt5.QtWidgets import QApplication, QVBoxLayout
import pandas as pd
import numpy as np
import threading
import random
import json
import sys
import os


# 继承ScriptWidget类
class interferometerMirrorMap(ScriptWidget):
    def __init__(self):
        super().__init__()
        self.ui = ui.Ui_Widget()
        self.ui.setupUi(self)
        self.running = False
        self.event = threading.Event()

        TOPICS = ['CTL_DR_ACS_Motion', "VSS_Com"]
        self.config = MetrologyConfig()

        self.paho_client = PahoMqttClient()
        self.paho_client.connect(str(self.config.MQTTHOST), int(self.config.MQTTPORT))
        self.paho_client.subscribe(TOPICS)
        self.mqtt_receive_worker = MqttReceiveWorker(self.paho_client, self.event)
        self.plc_client = PlcClient()

        self.res_fig = Figure()
        self.res_ax_x_mirror_TXY = self.res_fig.add_subplot(221)
        self.res_ax_x_mirror_Rz = self.res_fig.add_subplot(222)
        self.res_ax_y_mirror_TXY = self.res_fig.add_subplot(223)
        self.res_ax_y_mirror_Rz = self.res_fig.add_subplot(224)
        self.res_canvas = FigureCanvas(self.res_fig)
        self.res_fig_layout = QVBoxLayout()
        self.res_fig_layout.addWidget(self.res_canvas)
        self.ui.res_display.setLayout(self.res_fig_layout)
        self.res_canvas.draw()

        self.show_mirror_map()

    # 重写该函数，将所有需要保存的输入参数整理为list返回，输入的机器常数以json文件格式返回
    def get_saved_param(self):
        INPUT = {
            "start_x": self.ui.start_x.value(),
            "end_x": self.ui.end_x.value(),
            "start_y": self.ui.start_y.value(),
            "end_y": self.ui.end_y.value(),
            "step": self.ui.step.value()
        }
        return INPUT, {}

    # 重写该函数，其中param_list的内容和get_saved_param中自定义的list内容相同
    # 用于在脚本启动时读入保存的输入参数、机器常数
    def set_saved_param(self, param_dict, mc):
        self.ui.start_x.setValue(param_dict.get("start_x", 0))
        self.ui.end_x.setValue(param_dict.get("end_x", 0))
        self.ui.start_y.setValue(param_dict.get("start_y", 0))
        self.ui.end_y.setValue(param_dict.get("end_y", 0))
        self.ui.step.setValue(param_dict.get("step", 0))

    def plot_realtime_data(self, data):
        pass

    def plot_log(self, log_msg):
        pass

    def initial_before_run(self):
        pass

    # 重写该函数，具体的测试步骤
    def run(self, dict_input, dict_mc):
        self.running = True
        self.event.clear()
        self.mqtt_receive_worker.start()
        start_x = self.ui.start_x.value()
        end_x = self.ui.end_x.value()
        start_y = self.ui.start_y.value()
        end_y = self.ui.end_y.value()
        step = self.ui.step.value()

        sample_number_in_one_position = 50

        x_file_save_name = (self.config.DATA_SAVE_ROOT + "infer_mirror_SetY0_" + str(sample_number_in_one_position) + "_"
                            + time.strftime("%m%d%H%M") + "_cycle_{0}.csv")  # x运动，保存文件名
        y_file_save_name = (self.config.DATA_SAVE_ROOT + "infer_mirror_SetX0_" + str(sample_number_in_one_position) + "_"
                            + time.strftime("%m%d%H%M") + "_cycle_{0}.csv")  # y运动，保存文件名

        save_data_column_name = {"strip1", "strip2", "strip3", "strip4", "nominal x", "nominal y",
                                 "interferometer x", "interferometer y", "encoder x", "encoder y"}

        current_axis = 'COARSE_X'
        self.paho_client.publish("GUI_DR_ACS_Motion",
                                 mcmotion.MCMotion_CMD_one_axis_MoveAbs(
                                     pos=0,
                                     stage_name=LST_AXIS_NAME[current_axis]["name"],
                                     stage_index=LST_AXIS_NAME[current_axis]["index"],
                                     axis_name=LST_AXIS_NAME[current_axis]["axisName"]
                                 ),
                                 0)
        self.mqtt_receive_worker.wait_stage_stop()
        current_axis = 'COARSE_Y'
        self.paho_client.publish("GUI_DR_ACS_Motion",
                                 mcmotion.MCMotion_CMD_one_axis_MoveAbs(
                                     pos=0,
                                     stage_name=LST_AXIS_NAME[current_axis]["name"],
                                     stage_index=LST_AXIS_NAME[current_axis]["index"],
                                     axis_name=LST_AXIS_NAME[current_axis]["axisName"]
                                 ),
                                 0)
        self.mqtt_receive_worker.wait_stage_stop()
        self.plc_client.interferometer_set_zero()

        for x in range(start_x, end_x + step, step):
            # move X to x
            current_axis = 'COARSE_X'
            self.paho_client.publish("GUI_DR_ACS_Motion",
                                     mcmotion.MCMotion_CMD_one_axis_MoveAbs(
                                         pos=x,
                                         stage_name=LST_AXIS_NAME[current_axis]["name"],
                                         stage_index=LST_AXIS_NAME[current_axis]["index"],
                                         axis_name=LST_AXIS_NAME[current_axis]["axisName"]
                                     ),
                                     0)
            self.mqtt_receive_worker.wait_stage_stop()
            temp_save_data = []

        for y in range(start_y, end_y + step, step):
            # move X to x
            current_axis = 'COARSE_Y'
            self.paho_client.publish("GUI_DR_ACS_Motion",
                                     mcmotion.MCMotion_CMD_one_axis_MoveAbs(
                                         pos=y,
                                         stage_name=LST_AXIS_NAME[current_axis]["name"],
                                         stage_index=LST_AXIS_NAME[current_axis]["index"],
                                         axis_name=LST_AXIS_NAME[current_axis]["axisName"]
                                     ),
                                     0)
            self.mqtt_receive_worker.wait_stage_stop()
            temp_save_data = []

        self.mqtt_receive_worker.stop()

        df = pd.read_csv(x_file_save_name)
        x_MirrorTXY, x_MirrorRZ = calculate_x_mirror(df, os.path.dirname(x_file_save_name))
        df = pd.read_csv(y_file_save_name)
        y_MirrorTXY, y_MirrorRZ = calculate_y_mirror(df, os.path.dirname(y_file_save_name))

        self.show_mirror_map(x_MirrorTXY, x_MirrorRZ, y_MirrorTXY, y_MirrorRZ)

        return {}, {}

    # 重写该函数，打断时的操作
    def interrupt(self):
        self.event.set()
        self.running = False
        self.mqtt_receive_worker.stop()

    def append_to_text_edit(self,message):
        self.ui.textEdit.append(message)

    def show_mirror_map(self,
                        x_mirror_TXY = None, x_mirror_Rz = None,
                        y_mirror_TXY = None, y_mirror_Rz = None):

        self.res_ax_x_mirror_TXY.clear()
        self.res_ax_x_mirror_Rz.clear()
        self.res_ax_y_mirror_TXY.clear()
        self.res_ax_y_mirror_Rz.clear()

        if x_mirror_TXY is not None:
            self.res_ax_x_mirror_TXY.plot(x_mirror_TXY)
        if x_mirror_TXY is not None:
            self.res_ax_x_mirror_Rz.plot(x_mirror_Rz)
        if y_mirror_TXY is not None:
            self.res_ax_y_mirror_TXY.plot(y_mirror_TXY)
        if x_mirror_TXY is not None:
            self.res_ax_y_mirror_Rz.plot(y_mirror_Rz)

        self.res_ax_x_mirror_TXY.set_title("X TXY")
        self.res_ax_x_mirror_Rz.set_title("X Rz")
        self.res_ax_y_mirror_TXY.set_title("Y TXY")
        self.res_ax_y_mirror_Rz.set_title("Y Rz")
        self.res_fig.tight_layout()

        self.res_canvas.draw()

if __name__ == '__main__':
    myapp = QApplication(sys.argv)
    test = interferometerMirrorMap()
    test.show()
    sys.exit(myapp.exec_())
