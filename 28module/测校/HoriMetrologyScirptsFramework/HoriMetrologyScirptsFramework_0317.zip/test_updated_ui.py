# -*- coding: utf-8 -*-
import sys
from PyQt5.QtWidgets import QApplication, QWidget
from qt_custom_ui import create_spinbox, create_combobox, create_label, create_groupbox
from AlignStabilityDynamic_ui import Ui_Widget as AlignStabilityDynamicUi
from SpectralConfocalStability_ui import Ui_Widget as SpectralConfocalStabilityUi

if __name__ == "__main__":
    try:
        app = QApplication(sys.argv)
        app.setStyle("Fusion")
        
        # 测试qt_custom_ui组件
        print("Testing qt_custom_ui components...")
        
        # 测试create_spinbox
        spinbox = create_spinbox(0, 100, 2)
        spinbox.setValue(50.5)
        print("✓ create_spinbox created successfully")
        
        # 测试create_combobox
        combobox = create_combobox(["Option 1", "Option 2", "Option 3"])
        print("✓ create_combobox created successfully")
        
        # 测试create_label
        label = create_label("Test Label")
        print("✓ create_label created successfully")
        
        # 测试create_groupbox
        groupbox = create_groupbox("Test Group", 300)
        print("✓ create_groupbox created successfully")
        
        # 测试AlignStabilityDynamic_ui
        print("\nTesting AlignStabilityDynamic_ui...")
        align_window = QWidget()
        align_ui = AlignStabilityDynamicUi()
        align_ui.setupUi(align_window)
        print("✓ AlignStabilityDynamic_ui loaded successfully")
        
        # 测试SpectralConfocalStability_ui
        print("\nTesting SpectralConfocalStability_ui...")
        spectral_window = QWidget()
        spectral_ui = SpectralConfocalStabilityUi()
        spectral_ui.setupUi(spectral_window)
        print("✓ SpectralConfocalStability_ui loaded successfully")
        
        print("\nAll tests passed successfully!")
        
    except Exception as e:
        print(f"Error testing UI components: {e}")
        import traceback
        traceback.print_exc()
