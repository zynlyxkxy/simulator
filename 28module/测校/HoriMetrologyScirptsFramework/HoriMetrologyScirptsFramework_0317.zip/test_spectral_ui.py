# -*- coding: utf-8 -*-
import sys
from PyQt5.QtWidgets import QApplication, QWidget
from SpectralConfocalStability_ui import Ui_Widget

if __name__ == "__main__":
    try:
        app = QApplication(sys.argv)
        app.setStyle("Fusion")
        window = QWidget()
        ui = Ui_Widget()
        ui.setupUi(window)
        print("Spectral Confocal Stability UI loaded successfully!")
        print("Window title:", window.windowTitle())
        print("Window size:", window.size())
        print("UI components created:")
        print("- textEdit:", hasattr(ui, 'textEdit'))
        print("- sensor_ID:", hasattr(ui, 'sensor_ID'))
        print("- test_duration:", hasattr(ui, 'test_duration'))
        print("- test_interval:", hasattr(ui, 'test_interval'))
        print("- average_number:", hasattr(ui, 'average_number'))
        print("- res_display:", hasattr(ui, 'res_display'))
        print("\nSpectral Confocal Stability UI美化完成，界面已准备就绪！")
        # 不显示窗口，只验证UI加载
        # window.show()
        # sys.exit(app.exec_())
    except Exception as e:
        print(f"Error loading UI: {e}")
        import traceback
        traceback.print_exc()
