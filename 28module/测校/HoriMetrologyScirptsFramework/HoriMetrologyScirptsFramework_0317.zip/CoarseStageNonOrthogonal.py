# -*- coding: utf-8 -*-
"""
Filename: CoarseStageNonOrthogonal.py
Date: 2025/9/1
Description:
    粗动台非正交测试
"""
from metrology_config import MetrologyConfig
from ScriptWidget import ScriptWidget
from TestScriptWidget import TestScriptWidget
from cmdjson.PahoMqttClient import PahoMqttClient
from cmdjson.MC_Motion_cmd import LST_AXIS_NAME
from MqttReceiveWorker import MqttReceiveWorker
import cmdjson.MC_Motion_cmd as mcmotion
import cmdjson.Camera_CMD as mcCamera
import CoarseStageNonOrthogonal_ui as ui
from non_orthogonal_model import non_orthogonal_model
from RotationCalculator import RotationCalculator

from plc_grpc_client import PlcClient
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from PyQt5.QtWidgets import QApplication, QVBoxLayout
import pandas as pd
import numpy as np
import threading
import random
import json
import sys
import time


# 继承ScriptWidget类
class CoarseStageNonOrthogonal(TestScriptWidget):
    def __init__(self):
        super().__init__()
        self.ui = ui.Ui_Widget()
        self.ui.setupUi(self)
        self.running = False
        self.event = threading.Event()

        self.TOPICS = ['CTL_DR_ACS_Motion', "VSS_Com"]

        self.config = MetrologyConfig()

        self.paho_client = PahoMqttClient()
        self.paho_client.connect(str(self.config.MQTTHOST), int(self.config.MQTTPORT))
        self.mqtt_receive_worker = MqttReceiveWorker(self.paho_client, self.event)
        self.plc_client = PlcClient()

        self.pixel_size = self.config.camera_setting[0]['pixel_size']
        self.magnification = self.config.camera_setting[0]['magnification']
        self.image_center_x = self.config.camera_setting[0]['image_center_x']
        self.image_center_y = self.config.camera_setting[0]['image_center_y']

    # 重写该函数，将所有需要保存的输入参数整理为list返回，输入的机器常数以json文件格式返回
    def get_saved_param(self):
        INPUT = {
            'x_get_pic_pos_x_1': float(self.ui.x_get_pic_pos_x_1.value()),
            'x_get_pic_pos_y_1': float(self.ui.x_get_pic_pos_y_1.value()),
            'x_get_pic_pos_x_2': float(self.ui.x_get_pic_pos_x_2.value()),
            'x_get_pic_pos_y_2': float(self.ui.x_get_pic_pos_y_2.value()),
            'y_get_pic_pos_x_1': float(self.ui.y_get_pic_pos_x_1.value()),
            'y_get_pic_pos_y_1': float(self.ui.y_get_pic_pos_y_1.value()),
            'y_get_pic_pos_x_2': float(self.ui.y_get_pic_pos_x_2.value()),
            'y_get_pic_pos_y_2': float(self.ui.y_get_pic_pos_y_2.value()),
            'camera_ID': int(self.ui.camera_ID.value()),
            'vision_template': self.ui.cb_vision_template.text(),
            "repeat_time": int(self.ui.repeat_time.value()),
        }
        return INPUT, {}


    # 重写该函数，其中param_list的内容和get_saved_param中自定义的list内容相同
    # 用于在脚本启动时读入保存的输入参数、机器常数
    def set_saved_param(self, param_dict, mc):
        self.ui.camera_id.setValue(param_dict["camera_ID"])
        self.ui.repeat_time.setValue(param_dict["repeat_time"])
        self.ui.cb_vision_template.setCurrentText(param_dict["vision_template"])
        self.ui.x_get_pic_pos_x_1.setValue(param_dict.get(['x_get_pic_pos_x_1'], 0))
        self.ui.x_get_pic_pos_y_1.setValue(param_dict.get(['x_get_pic_pos_y_1'], 0))
        self.ui.x_get_pic_pos_x_2.setValue(param_dict.get(['x_get_pic_pos_x_2'], 0))
        self.ui.x_get_pic_pos_y_2.setValue(param_dict.get(['x_get_pic_pos_y_2'], 0))
        self.ui.y_get_pic_pos_x_1.setValue(param_dict.get(['y_get_pic_pos_x_1'], 0))
        self.ui.y_get_pic_pos_y_1.setValue(param_dict.get(['y_get_pic_pos_y_1'], 0))
        self.ui.y_get_pic_pos_x_2.setValue(param_dict.get(['y_get_pic_pos_x_2'], 0))
        self.ui.y_get_pic_pos_y_2.setValue(param_dict.get(['y_get_pic_pos_y_2'], 0))

    def plot_realtime_data(self, data):
        pass

    def plot_log(self, log_msg):
        pass

    def initial_before_run(self):
        pass

    # 重写该函数，具体的测试步骤
    def run(self, dict_input, dict_mc):
        self.running = True
        self.event.clear()
        self.paho_client.subscribe(self.TOPICS)
        self.mqtt_receive_worker.start()
        self.event.wait(1)
        # 参数设置
        camera_id = dict_input["camera_id"]
        repeat_time = dict_input["repeat_time"]
        vision_template = dict_input["vision_template"]
        x_stage_coordinate_list = [[self.ui.x_get_pic_pos_x_1.value(), self.ui.x_get_pic_pos_y_1.value()],
                                   [self.ui.x_get_pic_pos_x_2.value(), self.ui.x_get_pic_pos_y_2.value()]]  # x向坐标列表
        y_stage_coordinate_list = [[self.ui.y_get_pic_pos_x_1.value(), self.ui.y_get_pic_pos_y_1.value()],
                                   [self.ui.y_get_pic_pos_x_2.value(), self.ui.y_get_pic_pos_y_2.value()]]  # y向坐标列表

        X_interval = self.ui.x_interval.value()  # X向理论间隔
        Y_interval = self.ui.y_interval.value()  # Y向理论间隔

        detect_x_stage_position = []
        for cur_x_coordinate in x_stage_coordinate_list:
            detect_x_stage_position.append(self.get_mark_stage_position(camera_id, vision_template, cur_x_coordinate))
        detect_x_stage_position = np.array(detect_x_stage_position)

        detect_y_stage_position = []
        for cur_y_coordinate in y_stage_coordinate_list:
            detect_y_stage_position.append(self.get_mark_stage_position(camera_id, vision_template, cur_y_coordinate))
        detect_y_stage_position = np.array(detect_y_stage_position)

        X_rotation = non_orthogonal_model.X_rotation(coords=detect_x_stage_position)
        Y_rotation = non_orthogonal_model.Y_rotation(coords=detect_y_stage_position)
        self.append_to_res_text_edit(f'测校版上片倾斜（相对于X轴倾斜）={X_rotation}rad\n'
              f'相对于Y轴倾斜={Y_rotation}rad\n'
              f'Y轴相对于X轴的非正交={Y_rotation}-{X_rotation}={Y_rotation - X_rotation}rad')

        compensated_X_coords = non_orthogonal_model.Compensated_rotation(detect_x_stage_position, X_rotation)
        compensated_Y_coords = non_orthogonal_model.Compensated_rotation(detect_y_stage_position, X_rotation)

        a = np.mean(np.diff(compensated_X_coords[:, 0]) / X_interval)
        b = -np.tan(Y_rotation - X_rotation)
        c = 0
        d = np.mean(np.diff(compensated_Y_coords[:, 1]) / Y_interval)
        matrix = np.array([[a, b], [c, d]])
        matrix_inv = np.linalg.inv(matrix)
        self.append_to_res_text_edit(f'正向matrix：{np.round(matrix, 3)}\n'
                                     f'逆向matrix：{np.round(matrix_inv, 3)}')

        self.paho_client.unsubscribe(self.TOPICS)
        self.mqtt_receive_worker.stop()
        return {}, {}

    # 重写该函数，打断时的操作
    def interrupt(self):
        self.event.set()
        self.running = False
        self.mqtt_receive_worker.stop()
        self.paho_client.unsubscribe(self.TOPICS)

    def take_photo(self, camera_id, template_name):
        self.mqtt_receive_worker.reset_image_process_status()
        self.paho_client.publish("VSC_Com",
                            mcCamera.VisionCmdJsonHardTriggerType(id=camera_id, template=template_name, exposure=0),
                            0)
        self.plc_client.camera_trigger(camera_id)
        arr_row, arr_col = self.mqtt_receive_worker.wait_image_process()
        return arr_row, arr_col

    def get_mark_stage_position(self, camera_ID, vision_template, coarse_coordinate, inv_matrix=None):
        self.append_to_text_edit(f"{'-' * 10}> move to position ({coarse_coordinate})")

        current_axis = 'COARSE_X'
        self.paho_client.publish("GUI_DR_ACS_Motion",
                            mcmotion.MCMotion_CMD_one_axis_MoveAbs(pos=coarse_coordinate[0],
                                                                   stage_name=LST_AXIS_NAME[current_axis]["name"],
                                                                   stage_index=LST_AXIS_NAME[current_axis]["index"],
                                                                   axis_name=LST_AXIS_NAME[current_axis]["axisName"]),
                            0)
        self.mqtt_receive_worker.wait_stage_stop()
        current_axis = 'COARSE_Y'
        self.paho_client.publish("GUI_DR_ACS_Motion",
                            mcmotion.MCMotion_CMD_one_axis_MoveAbs(pos=coarse_coordinate[1],
                                                                   stage_name=LST_AXIS_NAME[current_axis]["name"],
                                                                   stage_index=LST_AXIS_NAME[current_axis]["index"],
                                                                   axis_name=LST_AXIS_NAME[current_axis]["axisName"]),
                            0)
        self.mqtt_receive_worker.wait_stage_stop()
        self.append_to_text_edit(f"{'-' * 10}> stage move end")

        self.append_to_text_edit(f"{'-' * 10}> take_photo start")
        start_pos_detect_row, start_pos_detect_col = self.take_photo(camera_ID, vision_template)
        self.append_to_text_edit(f"{'-' * 10}> take_photo end")

        coarse_stage_pos = self.mqtt_receive_worker.get_coarse_stage_pos()
        if inv_matrix is not None:
            coarse_stage_pos, _ = non_orthogonal_model.apply_compensation(coarse_stage_pos, inv_matrix)
        coarse_stage_pos[0] = -coarse_stage_pos[0]
        coarse_stage_pos[1] = -coarse_stage_pos[1]
        world_position = RotationCalculator.pixel_to_world([start_pos_detect_col, start_pos_detect_row],
                                                           coarse_stage_pos,
                                                           self.pixel_size, self.magnification,
                                                           self.image_center_x, self.image_center_y)
        self.append_to_text_edit(f"{'-' * 10}> calculate position ({world_position})")
        return [-world_position[0], -world_position[1]]

    def append_to_text_edit(self, message):
        self.ui.textEdit.append(message)

    def append_to_res_text_edit(self, message):
        self.ui.textEdit.append(message)


if __name__ == '__main__':
    myapp = QApplication(sys.argv)
    test = CoarseStageNonOrthogonal()
    # test.MqttClient.loop_start()
    test.show()
    # test.begin_()
    sys.exit(myapp.exec_())
    # test.MqttClient.loop_stop()
    # test.MqttClient.disconnect()
