# -*- coding: utf-8 -*-
import sys
from PyQt5.QtWidgets import QApplication, QWidget
from SingleCameraAlignStability_ui import Ui_Widget as SingleCameraAlignStabilityUi

if __name__ == "__main__":
    try:
        app = QApplication(sys.argv)
        app.setStyle("Fusion")
        
        # 测试SingleCameraAlignStability_ui
        print("Testing SingleCameraAlignStability_ui...")
        window = QWidget()
        ui = SingleCameraAlignStabilityUi()
        ui.setupUi(window)
        print("✓ SingleCameraAlignStability_ui loaded successfully")
        
        print("\nAll tests passed successfully!")
        
    except Exception as e:
        print(f"Error testing SingleCameraAlignStability_ui: {e}")
        import traceback
        traceback.print_exc()
