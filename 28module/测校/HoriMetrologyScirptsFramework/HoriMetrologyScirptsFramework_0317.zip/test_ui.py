# -*- coding: utf-8 -*-
import sys
from PyQt5.QtWidgets import QApplication, QWidget
from AlignStabilityDynamic_ui import Ui_Widget

if __name__ == "__main__":
    try:
        app = QApplication(sys.argv)
        app.setStyle("Fusion")
        window = QWidget()
        ui = Ui_Widget()
        ui.setupUi(window)
        print("UI loaded successfully!")
        print("Window title:", window.windowTitle())
        print("Window size:", window.size())
        print("UI components created:")
        print("- textEdit:", hasattr(ui, 'textEdit'))
        print("- camera_ID:", hasattr(ui, 'camera_ID'))
        print("- cb_vision_template:", hasattr(ui, 'cb_vision_template'))
        print("- repeat_times:", hasattr(ui, 'repeat_times'))
        print("- cb_stage_move_type:", hasattr(ui, 'cb_stage_move_type'))
        print("- stacked_widget:", hasattr(ui, 'stacked_widget'))
        print("- res_display:", hasattr(ui, 'res_display'))
        print("\nUI美化完成，界面已准备就绪！")
        # 不显示窗口，只验证UI加载
        # window.show()
        # sys.exit(app.exec_())
    except Exception as e:
        print(f"Error loading UI: {e}")
        import traceback
        traceback.print_exc()
