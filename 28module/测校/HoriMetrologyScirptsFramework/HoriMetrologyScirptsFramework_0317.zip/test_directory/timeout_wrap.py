# -*- coding: utf-8 -*-
"""
Filename: timeout_wrap.py
Author: Jianming.Liu
Date: 2025/11/24 
Description:
 
"""
import functools
from concurrent.futures import ThreadPoolExecutor, TimeoutError


def method_timeout(seconds):
    """
    专门为类方法设计的超时装饰器
    """

    def decorator(method):
        @functools.wraps(method)
        def wrapper(self, *args, **kwargs):
            # 绑定self到方法，确保能正确访问实例属性
            bound_method = method.__get__(self, type(self))
            with ThreadPoolExecutor(max_workers=1) as executor:
                future = executor.submit(bound_method, *args, **kwargs)
                try:
                    return future.result(timeout=seconds)
                except TimeoutError:
                    future.cancel()
                    raise TimeoutError(f"Method {method.__name__} exceeded {seconds} seconds")

        return wrapper

    return decorator


class DataProcessor:
    def __init__(self, name):
        self.name = name
        self.processed_count = 0

    @method_timeout(4)
    def heavy_processing(self, data_size):
        """耗时处理方法"""
        import time
        print(f"{self.name} 开始处理数据，大小: {data_size}")
        time.sleep(5)  # 模拟耗时操作
        self.processed_count += 1
        return f"处理完成，累计处理: {self.processed_count}"

    @method_timeout(2)
    def quick_check(self):
        """快速检查方法"""
        import time
        time.sleep(1.5)
        return f"检查完成: {self.name}"


# 使用示例
processor = DataProcessor("处理器1")
try:
    result = processor.heavy_processing(1000)
    print(result)
except TimeoutError as e:
    print(f"处理超时: {e}")

try:
    result = processor.quick_check()
    print(result)
except TimeoutError as e:
    print(f"检查超时: {e}")

