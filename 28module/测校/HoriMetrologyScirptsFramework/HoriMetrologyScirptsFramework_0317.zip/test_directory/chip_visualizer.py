import sys
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QPushButton, QLabel, QMessageBox,
                             QInputDialog, QToolTip)
from PyQt5.QtCore import Qt, QPoint, QRect, QTimer, pyqtSignal
from PyQt5.QtGui import QPainter, QPen, QBrush, QColor, QFont, QPainterPath, QCursor


class Chip:
    """芯片类，用于存储芯片的位置、大小和状态信息"""
    
    def __init__(self, center_x, center_y, width, height, chip_id=None):
        self.center_x = int(center_x)
        self.center_y = int(center_y)
        self.width = int(width)
        self.height = int(height)
        self.chip_id = chip_id or id(self)
        self.selected = False
        self.hovered = False
        
    @property
    def left(self):
        """芯片左边界的x坐标"""
        return int(self.center_x - self.width // 2)
    
    @property
    def top(self):
        """芯片上边界的y坐标"""
        return int(self.center_y - self.height // 2)
    
    @property
    def right(self):
        """芯片右边界的x坐标"""
        return int(self.center_x + self.width // 2)
    
    @property
    def bottom(self):
        """芯片下边界的y坐标"""
        return int(self.center_y + self.height // 2)
    
    @property
    def rect(self):
        """返回芯片的矩形区域"""
        return QRect(self.left, self.top, self.width, self.height)
    
    def contains(self, point):
        """判断点是否在芯片内"""
        return self.left <= point.x() <= self.right and self.top <= point.y() <= self.bottom
    
    def intersects(self, other_chip):
        """判断两个芯片是否重叠"""
        return not (self.right < other_chip.left or 
                   self.left > other_chip.right or 
                   self.bottom < other_chip.top or 
                   self.top > other_chip.bottom)
    
    def distance_to(self, other_chip):
        """计算两个芯片中心点之间的距离"""
        import math
        dx = self.center_x - other_chip.center_x
        dy = self.center_y - other_chip.center_y
        return math.sqrt(dx * dx + dy * dy)
    
    def __repr__(self):
        return f"Chip(id={self.chip_id}, center=({self.center_x}, {self.center_y}), size={self.width}x{self.height}, selected={self.selected})"


class ChipWidget(QWidget):
    """芯片绘制区域，负责绘制芯片和处理鼠标交互"""
    
    # 定义信号
    chip_selected = pyqtSignal(Chip)  # 芯片被选中时发射的信号
    chip_hovered = pyqtSignal(Chip)   # 鼠标悬停在芯片上时发射的信号
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.chips = []  # 存储所有芯片
        self.selected_chips = []  # 存储选中的芯片
        self.hovered_chip = None  # 当前悬停的芯片
        self.chip_counter = 0  # 芯片计数器
        
        # 设置背景色
        self.setStyleSheet("background-color: #2b2b2b;")
        
        # 设置鼠标追踪，以便捕获鼠标移动事件
        self.setMouseTracking(True)
        
        # 设置最小尺寸
        self.setMinimumSize(600, 400)
        
        # 初始化一些示例芯片（可选）
        # self.add_sample_chips()
    
    def add_sample_chips(self):
        """添加一些示例芯片用于测试"""
        sample_data = [
            (100, 100, 80, 60),
            (250, 150, 100, 80),
            (400, 200, 90, 70),
            (150, 300, 85, 65),
            (350, 350, 95, 75),
        ]
        
        for center_x, center_y, width, height in sample_data:
            self.add_chip(center_x, center_y, width, height)
    
    def add_chip(self, center_x, center_y, width, height):
        """
        添加一个芯片，如果位置重叠则自动调整位置
        返回：添加的芯片对象
        """
        self.chip_counter += 1
        new_chip = Chip(center_x, center_y, width, height, f"chip_{self.chip_counter}")
        
        # 检查是否与现有芯片重叠，如果重叠则调整位置
        if self.check_overlap(new_chip):
            new_position = self.find_non_overlapping_position(new_chip)
            if new_position:
                new_chip.center_x, new_chip.center_y = new_position
        
        self.chips.append(new_chip)
        self.update()  # 重绘界面
        return new_chip
    
    def check_overlap(self, chip):
        """检查芯片是否与现有芯片重叠"""
        for existing_chip in self.chips:
            if chip.intersects(existing_chip):
                return True
        return False
    
    def find_non_overlapping_position(self, chip, max_attempts=50):
        """
        为重叠的芯片寻找新的不重叠位置
        使用螺旋搜索算法，从原始位置开始向外扩展
        """
        import math
        
        original_x, original_y = chip.center_x, chip.center_y
        spacing = 20  # 芯片之间的最小间距
        
        for attempt in range(max_attempts):
            # 使用螺旋搜索模式
            angle = (attempt * 137.5) * math.pi / 180  # 黄金角度，确保均匀分布
            radius = (attempt // 8 + 1) * (max(chip.width, chip.height) + spacing)
            
            new_x = int(original_x + radius * math.cos(angle))
            new_y = int(original_y + radius * math.sin(angle))
            
            # 确保芯片在窗口范围内
            margin = max(chip.width, chip.height) // 2 + 10
            new_x = max(margin, min(new_x, self.width() - margin))
            new_y = max(margin, min(new_y, self.height() - margin))
            
            # 更新芯片位置并检查重叠
            chip.center_x, chip.center_y = new_x, new_y
            if not self.check_overlap(chip):
                return new_x, new_y
        
        # 如果找不到位置，返回None
        return None
    
    def get_chip_at(self, pos):
        """获取指定位置的芯片（从后往前查找，最上层的优先）"""
        for chip in reversed(self.chips):
            if chip.contains(pos):
                return chip
        return None
    
    def select_chip(self, chip, multi_select=False):
        """
        选择芯片
        chip: 要选择的芯片
        multi_select: 是否多选（按住Ctrl时）
        """
        if not multi_select:
            # 单选模式，清除其他选择
            for c in self.selected_chips:
                c.selected = False
            self.selected_chips.clear()
        
        # 切换选择状态
        if chip in self.selected_chips:
            chip.selected = False
            self.selected_chips.remove(chip)
        else:
            chip.selected = True
            self.selected_chips.append(chip)
        
        self.update()  # 重绘
        self.chip_selected.emit(chip)  # 发射信号
    
    def clear_selection(self):
        """清除所有选择"""
        for chip in self.selected_chips:
            chip.selected = False
        self.selected_chips.clear()
        self.update()
    
    def get_selected_chips_info(self):
        """获取选中芯片的信息"""
        info_list = []
        for chip in self.selected_chips:
            info = {
                'id': chip.chip_id,
                'center_x': chip.center_x,
                'center_y': chip.center_y,
                'width': chip.width,
                'height': chip.height,
                'left': chip.left,
                'top': chip.top,
                'right': chip.right,
                'bottom': chip.bottom
            }
            info_list.append(info)
        return info_list
    
    def paintEvent(self, event):
        """重绘事件"""
        super().paintEvent(event)
        
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)  # 抗锯齿
        
        # 绘制网格背景（可选）
        self.draw_grid(painter)
        
        # 绘制所有芯片
        for chip in self.chips:
            self.draw_chip(painter, chip)
        
        # 绘制选中芯片的信息
        self.draw_selection_info(painter)
    
    def draw_grid(self, painter):
        """绘制网格背景"""
        pen = QPen(QColor(50, 50, 50), 1, Qt.SolidLine)
        painter.setPen(pen)
        
        grid_size = 20
        for x in range(0, self.width(), grid_size):
            painter.drawLine(x, 0, x, self.height())
        for y in range(0, self.height(), grid_size):
            painter.drawLine(0, y, self.width(), y)
    
    def draw_chip(self, painter, chip):
        """绘制单个芯片"""
        rect = chip.rect
        
        # 根据状态设置颜色和画笔
        if chip.selected:
            # 选中的芯片 - 蓝色
            brush_color = QColor(33, 150, 243, 180)
            pen_color = QColor(33, 150, 243)
            pen_width = 3
        elif chip.hovered:
            # 悬停的芯片 - 橙色
            brush_color = QColor(255, 152, 0, 180)
            pen_color = QColor(255, 152, 0)
            pen_width = 2
        else:
            # 普通芯片 - 绿色
            brush_color = QColor(76, 175, 80, 150)
            pen_color = QColor(76, 175, 80)
            pen_width = 2
        
        # 设置画笔和画刷
        pen = QPen(pen_color, pen_width, Qt.SolidLine)
        brush = QBrush(brush_color, Qt.SolidPattern)
        painter.setPen(pen)
        painter.setBrush(brush)
        
        # 绘制芯片矩形
        painter.drawRect(rect)
        
        # 绘制芯片ID
        painter.setPen(QColor(255, 255, 255))
        font = QFont("Arial", 10, QFont.Bold)
        painter.setFont(font)
        
        # 计算文本位置（居中）
        text = str(chip.chip_id)
        text_rect = painter.fontMetrics().boundingRect(text)
        text_x = int(chip.center_x - text_rect.width() // 2)
        text_y = int(chip.center_y + text_rect.height() // 2)
        
        painter.drawText(text_x, text_y, text)
        
        # 如果是选中的芯片，绘制中心点
        if chip.selected:
            painter.setPen(QPen(QColor(255, 255, 255), 2))
            painter.drawEllipse(int(chip.center_x - 3), int(chip.center_y - 3), 6, 6)
    
    def draw_selection_info(self, painter):
        """绘制选中芯片的信息"""
        if not self.selected_chips:
            return
        
        # 在左上角显示选中芯片的数量
        painter.setPen(QColor(255, 255, 255))
        font = QFont("Arial", 12, QFont.Bold)
        painter.setFont(font)
        
        info_text = f"已选择: {len(self.selected_chips)} 个芯片"
        painter.drawText(10, 25, info_text)
    
    def mousePressEvent(self, event):
        """鼠标按下事件"""
        if event.button() == Qt.LeftButton:
            chip = self.get_chip_at(event.pos())
            if chip:
                # 按住Ctrl可以多选
                multi_select = event.modifiers() & Qt.ControlModifier
                self.select_chip(chip, multi_select)
            else:
                # 点击空白处清除选择
                if not (event.modifiers() & Qt.ControlModifier):
                    self.clear_selection()
        
        super().mousePressEvent(event)
    
    def mouseMoveEvent(self, event):
        """鼠标移动事件"""
        # 更新悬停状态
        chip = self.get_chip_at(event.pos())
        
        if chip != self.hovered_chip:
            # 清除之前的悬停状态
            if self.hovered_chip:
                self.hovered_chip.hovered = False
            
            # 设置新的悬停状态
            self.hovered_chip = chip
            if chip:
                chip.hovered = True
                # 显示工具提示
                QToolTip.showText(
                    QCursor.pos(),
                    f"芯片: {chip.chip_id}\n"
                    f"中心: ({chip.center_x}, {chip.center_y})\n"
                    f"大小: {chip.width} x {chip.height}\n"
                    f"范围: ({chip.left}, {chip.top}) - ({chip.right}, {chip.bottom})",
                    self
                )
                self.chip_hovered.emit(chip)
            else:
                QToolTip.hideText()
            
            self.update()
        
        super().mouseMoveEvent(event)
    
    def mouseDoubleClickEvent(self, event):
        """鼠标双击事件 - 用于编辑芯片"""
        if event.button() == Qt.LeftButton:
            chip = self.get_chip_at(event.pos())
            if chip:
                self.edit_chip(chip)
        
        super().mouseDoubleClickEvent(event)
    
    def edit_chip(self, chip):
        """编辑芯片属性"""
        # 这里可以添加编辑对话框，简化版本直接跳过
        QMessageBox.information(
            self, 
            "编辑芯片", 
            f"芯片 {chip.chip_id}\n"
            f"中心位置: ({chip.center_x}, {chip.center_y})\n"
            f"尺寸: {chip.width} x {chip.height}"
        )
    
    def resizeEvent(self, event):
        """窗口大小改变事件"""
        super().resizeEvent(event)
        self.update()


class MainWindow(QMainWindow):
    """主窗口类"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("芯片位置可视化工具")
        self.setGeometry(100, 100, 800, 600)
        
        # 创建中心部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 创建布局
        main_layout = QHBoxLayout(central_widget)
        
        # 创建芯片绘制区域
        self.chip_widget = ChipWidget()
        main_layout.addWidget(self.chip_widget, 1)
        
        # 创建控制面板
        control_panel = self.create_control_panel()
        main_layout.addWidget(control_panel)
        
        # 连接信号
        self.chip_widget.chip_selected.connect(self.on_chip_selected)
        self.chip_widget.chip_hovered.connect(self.on_chip_hovered)
        
        # 添加示例芯片
        self.add_sample_chips()
    
    def create_control_panel(self):
        """创建控制面板"""
        panel = QWidget()
        panel.setMaximumWidth(250)
        panel.setStyleSheet("""
            QWidget {
                background-color: #3c3c3c;
                border-left: 2px solid #555;
            }
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 10px;
                font-size: 14px;
                font-weight: bold;
                border-radius: 5px;
                margin: 5px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:pressed {
                background-color: #3d8b40;
            }
            QLabel {
                color: white;
                font-size: 13px;
                padding: 5px;
            }
        """)
        
        layout = QVBoxLayout(panel)
        
        # 标题
        title = QLabel("芯片控制面板")
        title.setAlignment(Qt.AlignCenter)
        title_font = QFont("Arial", 16, QFont.Bold)
        title.setFont(title_font)
        layout.addWidget(title)
        
        layout.addSpacing(10)
        
        # 添加芯片按钮
        add_chip_btn = QPushButton("添加芯片")
        add_chip_btn.clicked.connect(self.on_add_chip_clicked)
        layout.addWidget(add_chip_btn)
        
        # 打印选中芯片按钮
        print_selected_btn = QPushButton("打印选中芯片位置")
        print_selected_btn.clicked.connect(self.on_print_selected_clicked)
        layout.addWidget(print_selected_btn)
        
        # 清除选择按钮
        clear_selection_btn = QPushButton("清除选择")
        clear_selection_btn.clicked.connect(self.chip_widget.clear_selection)
        layout.addWidget(clear_selection_btn)
        
        # 删除选中芯片按钮
        delete_selected_btn = QPushButton("删除选中芯片")
        delete_selected_btn.clicked.connect(self.on_delete_selected_clicked)
        layout.addWidget(delete_selected_btn)
        
        layout.addSpacing(10)
        
        # 信息显示区域
        info_group = QLabel("信息统计")
        info_group.setStyleSheet("font-weight: bold; font-size: 14px; border-bottom: 1px solid #555; padding-bottom: 5px;")
        layout.addWidget(info_group)
        
        # 芯片总数标签
        self.total_chips_label = QLabel(f"芯片总数: {len(self.chip_widget.chips)}")
        layout.addWidget(self.total_chips_label)
        
        # 选中数量标签
        self.selected_count_label = QLabel("选中数量: 0")
        layout.addWidget(self.selected_count_label)
        
        # 鼠标位置标签
        self.mouse_pos_label = QLabel("鼠标位置: (0, 0)")
        layout.addWidget(self.mouse_pos_label)
        
        layout.addSpacing(10)
        
        # 操作说明
        instruction_group = QLabel("操作说明")
        instruction_group.setStyleSheet("font-weight: bold; font-size: 14px; border-bottom: 1px solid #555; padding-bottom: 5px;")
        layout.addWidget(instruction_group)
        
        instructions = QLabel(
            "• 左键单击: 选择芯片\n"
            "• Ctrl+左键: 多选\n"
            "• 空白处点击: 清除选择\n"
            "• 鼠标悬停: 显示位置信息\n"
            "• 双击芯片: 编辑属性"
        )
        instructions.setWordWrap(True)
        layout.addWidget(instructions)
        
        layout.addStretch()
        
        return panel
    
    def add_sample_chips(self):
        """添加示例芯片"""
        # 添加一些示例芯片
        sample_chips = [
            (150, 120, 80, 60),
            (300, 180, 100, 80),
            (500, 150, 90, 70),
            (200, 300, 85, 65),
            (450, 320, 95, 75),
            (120, 250, 75, 55),
            (380, 220, 110, 85),
        ]
        
        for center_x, center_y, width, height in sample_chips:
            self.chip_widget.add_chip(center_x, center_y, width, height)
        
        self.update_info_labels()
    
    def on_add_chip_clicked(self):
        """添加芯片按钮点击事件"""
        # 获取芯片参数
        center_x, ok1 = QInputDialog.getInt(self, "添加芯片", "请输入中心点X坐标:", 200, 0, 1000)
        if not ok1:
            return
        
        center_y, ok2 = QInputDialog.getInt(self, "添加芯片", "请输入中心点Y坐标:", 200, 0, 1000)
        if not ok2:
            return
        
        width, ok3 = QInputDialog.getInt(self, "添加芯片", "请输入芯片宽度:", 80, 20, 300)
        if not ok3:
            return
        
        height, ok4 = QInputDialog.getInt(self, "添加芯片", "请输入芯片高度:", 60, 20, 300)
        if not ok4:
            return
        
        # 添加芯片
        chip = self.chip_widget.add_chip(center_x, center_y, width, height)
        self.update_info_labels()
        
        QMessageBox.information(self, "添加成功", f"芯片 {chip.chip_id} 添加成功！\n位置: ({chip.center_x}, {chip.center_y})")
    
    def on_print_selected_clicked(self):
        """打印选中芯片位置"""
        selected_chips = self.chip_widget.get_selected_chips_info()
        
        if not selected_chips:
            QMessageBox.warning(self, "警告", "请先选择至少一个芯片！")
            return
        
        print("\n" + "="*60)
        print("选中的芯片位置信息:")
        print("="*60)
        
        for i, info in enumerate(selected_chips, 1):
            print(f"\n芯片 {i}:")
            print(f"  ID: {info['id']}")
            print(f"  中心位置: ({info['center_x']}, {info['center_y']})")
            print(f"  尺寸: {info['width']} x {info['height']}")
            print(f"  范围: 左上角({info['left']}, {info['top']}) - 右下角({info['right']}, {info['bottom']})")
        
        print("="*60)
        print(f"总计: {len(selected_chips)} 个芯片\n")
        
        # 在界面上也显示一下
        QMessageBox.information(
            self, 
            "打印完成", 
            f"已在控制台打印 {len(selected_chips)} 个选中芯片的位置信息！\n\n"
            f"请查看控制台输出。"
        )
    
    def on_delete_selected_clicked(self):
        """删除选中芯片"""
        selected_chips = [chip for chip in self.chip_widget.chips if chip.selected]
        
        if not selected_chips:
            QMessageBox.warning(self, "警告", "请先选择要删除的芯片！")
            return
        
        reply = QMessageBox.question(
            self, 
            "确认删除", 
            f"确定要删除选中的 {len(selected_chips)} 个芯片吗？",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            # 从列表中移除选中的芯片
            for chip in selected_chips:
                self.chip_widget.chips.remove(chip)
            
            # 清空选择列表
            self.chip_widget.selected_chips.clear()
            
            # 更新显示
            self.chip_widget.update()
            self.update_info_labels()
            
            QMessageBox.information(self, "删除成功", f"已删除 {len(selected_chips)} 个芯片！")
    
    def on_chip_selected(self, chip):
        """芯片被选中时的回调"""
        self.update_info_labels()
    
    def on_chip_hovered(self, chip):
        """芯片被悬停时的回调"""
        # 这里可以添加额外的悬停处理逻辑
        pass
    
    def update_info_labels(self):
        """更新信息标签"""
        self.total_chips_label.setText(f"芯片总数: {len(self.chip_widget.chips)}")
        self.selected_count_label.setText(f"选中数量: {len(self.chip_widget.selected_chips)}")
    
    def mouseMoveEvent(self, event):
        """鼠标移动事件 - 更新鼠标位置显示"""
        super().mouseMoveEvent(event)
        
        # 将全局坐标转换为芯片区域的局部坐标
        chip_widget_pos = self.chip_widget.mapFromGlobal(self.mapToGlobal(event.pos()))
        if self.chip_widget.rect().contains(chip_widget_pos):
            self.mouse_pos_label.setText(f"鼠标位置: ({chip_widget_pos.x()}, {chip_widget_pos.y()})")
        else:
            self.mouse_pos_label.setText("鼠标位置: (区域外)")


def main():
    """主函数"""
    app = QApplication(sys.argv)
    
    # 设置应用程序样式
    app.setStyle('Fusion')
    
    # 创建主窗口
    window = MainWindow()
    window.show()
    
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
