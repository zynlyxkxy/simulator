#!/usr/bin/env python3
"""
芯片类测试脚本
用于验证Chip类的核心功能，不依赖PyQt5
"""


class Chip:
    """芯片类，用于存储芯片的位置、大小和状态信息"""
    
    def __init__(self, center_x, center_y, width, height, chip_id=None):
        self.center_x = int(center_x)
        self.center_y = int(center_y)
        self.width = int(width)
        self.height = int(height)
        self.chip_id = chip_id or id(self)
        self.selected = False
        self.hovered = False
        
    @property
    def left(self):
        """芯片左边界的x坐标"""
        return int(self.center_x - self.width // 2)
    
    @property
    def top(self):
        """芯片上边界的y坐标"""
        return int(self.center_y - self.height // 2)
    
    @property
    def right(self):
        """芯片右边界的x坐标"""
        return int(self.center_x + self.width // 2)
    
    @property
    def bottom(self):
        """芯片下边界的y坐标"""
        return int(self.center_y + self.height // 2)
    
    def contains(self, point):
        """判断点是否在芯片内"""
        x, y = point
        return self.left <= x <= self.right and self.top <= y <= self.bottom
    
    def intersects(self, other_chip):
        """判断两个芯片是否重叠"""
        return not (self.right < other_chip.left or 
                   self.left > other_chip.right or 
                   self.bottom < other_chip.top or 
                   self.top > other_chip.bottom)
    
    def distance_to(self, other_chip):
        """计算两个芯片中心点之间的距离"""
        import math
        dx = self.center_x - other_chip.center_x
        dy = self.center_y - other_chip.center_y
        return math.sqrt(dx * dx + dy * dy)
    
    def __repr__(self):
        return f"Chip(id={self.chip_id}, center=({self.center_x}, {self.center_y}), size={self.width}x{self.height}, selected={self.selected})"


def test_chip_functionality():
    """测试芯片类的各项功能"""
    print("=" * 60)
    print("芯片类功能测试")
    print("=" * 60)
    
    # 测试1: 创建芯片
    print("\n【测试1】创建芯片")
    chip1 = Chip(100, 100, 80, 60, "chip_001")
    chip2 = Chip(250, 150, 100, 80, "chip_002")
    
    print(f"芯片1: {chip1}")
    print(f"芯片2: {chip2}")
    
    # 测试2: 位置计算
    print("\n【测试2】位置计算")
    print(f"芯片1 左边界: {chip1.left}, 上边界: {chip1.top}, 右边界: {chip1.right}, 下边界: {chip1.bottom}")
    print(f"芯片2 左边界: {chip2.left}, 上边界: {chip2.top}, 右边界: {chip2.right}, 下边界: {chip2.bottom}")
    
    # 测试3: 点包含测试
    print("\n【测试3】点包含测试")
    test_points = [(110, 110), (90, 90), (150, 130), (200, 200)]
    for point in test_points:
        result = chip1.contains(point)
        print(f"点{point} 在芯片1内: {result}")
    
    # 测试4: 重叠测试
    print("\n【测试4】重叠测试")
    print(f"芯片1和芯片2是否重叠: {chip1.intersects(chip2)}")
    
    # 创建重叠的芯片
    chip3 = Chip(120, 120, 60, 50, "chip_003")
    print(f"芯片1和芯片3是否重叠: {chip1.intersects(chip3)}")
    
    # 测试5: 选择状态
    print("\n【测试5】选择状态")
    print(f"芯片1选择状态: {chip1.selected}")
    chip1.selected = True
    print(f"设置选择后: {chip1.selected}")
    
    # 测试6: 悬停状态
    print("\n【测试6】悬停状态")
    print(f"芯片1悬停状态: {chip1.hovered}")
    chip1.hovered = True
    print(f"设置悬停后: {chip1.hovered}")
    
    print("\n" + "=" * 60)
    print("所有测试通过！")
    print("=" * 60)


def test_non_overlapping_algorithm():
    """测试不重叠算法"""
    print("\n" + "=" * 60)
    print("不重叠算法测试")
    print("=" * 60)
    
    chips = []
    
    # 添加第一个芯片
    chip1 = Chip(100, 100, 80, 60, "chip_001")
    chips.append(chip1)
    print(f"添加芯片1: 位置({chip1.center_x}, {chip1.center_y})")
    
    # 添加第二个芯片（会重叠）
    chip2 = Chip(120, 120, 80, 60, "chip_002")
    if check_overlap_with_list(chip2, chips):
        print(f"芯片2位置({chip2.center_x}, {chip2.center_y})与现有芯片重叠")
        # 手动调整位置
        chip2.center_x = 250
        chip2.center_y = 150
    chips.append(chip2)
    print(f"调整后的芯片2: 位置({chip2.center_x}, {chip2.center_y})")
    
    # 检查重叠
    print(f"芯片1和芯片2是否重叠: {chip1.intersects(chip2)}")
    
    print("=" * 60)


def check_overlap_with_list(chip, chip_list):
    """检查芯片是否与列表中的芯片重叠"""
    for existing_chip in chip_list:
        if chip.intersects(existing_chip):
            return True
    return False


if __name__ == "__main__":
    test_chip_functionality()
    test_non_overlapping_algorithm()
