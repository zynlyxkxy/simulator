import sys
import csv
from PyQt5.QtCore import Qt, QAbstractTableModel, QModelIndex
from PyQt5.QtWidgets import (QApplication, QMainWindow, QTableView,
                             QWidget, QVBoxLayout, QHBoxLayout,
                             QPushButton, QFileDialog, QMessageBox, QHeaderView)


class TableDataModel(QAbstractTableModel):
    """
    自定义表格数据模型，继承自QAbstractTableModel。
    负责管理表格的底层数据，并通知视图更新。
    """

    def __init__(self, data=None, headers=None):
        super().__init__()
        # 初始化表头和数据
        self._headers = headers if headers else ['x', 'y', 'z', 'camera_ID', 'template_name']
        self._data = data if data is not None else []

    def rowCount(self, parent=QModelIndex()):
        # 返回表格的行数
        return len(self._data)

    def columnCount(self, parent=QModelIndex()):
        # 返回表格的列数
        return len(self._headers)

    def data(self, index, role=Qt.DisplayRole):
        # 返回指定索引位置的数据，用于显示
        if not index.isValid() or role != Qt.DisplayRole:
            return None
        row, col = index.row(), index.column()
        if 0 <= row < len(self._data) and 0 <= col < len(self._headers):
            return str(self._data[row][col])
        return None

    def setData(self, index, value, role=Qt.EditRole):
        # 设置指定索引位置的数据，支持编辑
        if not index.isValid() or role != Qt.EditRole:
            return False
        row, col = index.row(), index.column()
        if 0 <= row < len(self._data) and 0 <= col < len(self._headers):
            self._data[row][col] = value
            # 发出数据变化信号，通知视图更新[citation:1]
            self.dataChanged.emit(index, index, [role])
            return True
        return False

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        # 返回表头数据
        if role != Qt.DisplayRole:
            return None
        if orientation == Qt.Horizontal and 0 <= section < len(self._headers):
            return self._headers[section]
        return None

    def flags(self, index):
        # 设置单元格标志，使表格可编辑
        return super().flags(index) | Qt.ItemIsEditable

    def insertRows(self, position, rows=1, parent=QModelIndex()):
        # 在指定位置插入新行（空数据）
        if position < 0 or position > len(self._data):
            return False
        # 必须调用begin/end通知视图进行更新[citation:1]
        self.beginInsertRows(parent, position, position + rows - 1)
        for _ in range(rows):
            # 插入一行空数据
            self._data.insert(position, [''] * self.columnCount())
        self.endInsertRows()
        return True

    def removeRows(self, position, rows=1, parent=QModelIndex()):
        # 从指定位置开始删除指定行数的数据
        if position < 0 or position + rows > len(self._data):
            return False
        # 必须调用begin/end通知视图进行更新[citation:1]
        self.beginRemoveRows(parent, position, position + rows - 1)
        del self._data[position:position + rows]
        self.endRemoveRows()
        return True

    def get_all_data(self):
        # 获取所有表格数据
        return self._data.copy()

    def load_data(self, new_data):
        # 加载新数据并重置模型
        self.beginResetModel()
        self._data = new_data
        self.endResetModel()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PyQt5 表格控件 - 数据管理")
        self.setGeometry(100, 100, 800, 500)
        self.init_ui()

    def init_ui(self):
        # 创建中心部件和主布局
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        # 创建表格视图和数据模型
        self.table_view = QTableView()
        self.model = TableDataModel()  # 使用自定义模型
        self.table_view.setModel(self.model)

        # 设置表格选择行为：选中整行[citation:5]
        self.table_view.setSelectionBehavior(QTableView.SelectRows)
        # 设置列宽自适应内容
        self.table_view.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        main_layout.addWidget(self.table_view)

        # 创建按钮布局
        button_layout = QHBoxLayout()

        # 添加行按钮
        self.add_button = QPushButton("添加行")
        self.add_button.clicked.connect(self.add_row)
        button_layout.addWidget(self.add_button)

        # 删除行按钮
        self.delete_button = QPushButton("删除选中行")
        self.delete_button.clicked.connect(self.delete_rows)
        button_layout.addWidget(self.delete_button)

        # 导入数据按钮
        self.import_button = QPushButton("导入CSV")
        self.import_button.clicked.connect(self.import_csv)
        button_layout.addWidget(self.import_button)

        # 导出数据按钮
        self.export_button = QPushButton("导出CSV")
        self.export_button.clicked.connect(self.export_csv)
        button_layout.addWidget(self.export_button)

        # 清空按钮
        self.clear_button = QPushButton("清空表格")
        self.clear_button.clicked.connect(self.clear_table)
        button_layout.addWidget(self.clear_button)

        button_layout.addStretch()
        main_layout.addLayout(button_layout)

    def add_row(self):
        """在表格末尾添加一个新行"""
        row_count = self.model.rowCount()
        self.model.insertRows(row_count)

    def delete_rows(self):
        """删除所有选中的行"""
        selection_model = self.table_view.selectionModel()
        if not selection_model.hasSelection():
            QMessageBox.warning(self, "警告", "请先选择要删除的行！")
            return

        # 获取所有选中的行索引（可能有多个）[citation:8]
        selected_rows = selection_model.selectedRows()
        if not selected_rows:
            return

        # 从后向前删除，避免索引变化导致的问题
        rows_to_delete = sorted([index.row() for index in selected_rows], reverse=True)
        for row in rows_to_delete:
            self.model.removeRows(row)

    def import_csv(self):
        """从CSV文件导入数据[citation:2]"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "选择CSV文件", "", "CSV Files (*.csv);;All Files (*)"
        )
        if not file_path:
            return

        try:
            with open(file_path, 'r', newline='', encoding='utf-8') as file:
                reader = csv.reader(file)
                data = list(reader)

            if data:
                # 假设第一行是表头，检查列数是否匹配
                if len(data[0]) != self.model.columnCount():
                    QMessageBox.warning(self, "导入失败",
                                        f"CSV文件列数({len(data[0])})与表格列数({self.model.columnCount()})不匹配！")
                    return

                # 加载数据到模型
                self.model.load_data(data)
                QMessageBox.information(self, "导入成功", f"已成功导入 {len(data)} 行数据！")
        except Exception as e:
            QMessageBox.critical(self, "导入失败", f"读取CSV文件时出错：{str(e)}")

    def export_csv(self):
        """将表格数据导出为CSV文件[citation:2][citation:9]"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "保存CSV文件", "table_data.csv", "CSV Files (*.csv);;All Files (*)"
        )
        if not file_path:
            return

        try:
            data = self.model.get_all_data()
            with open(file_path, 'w', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                # 写入表头
                writer.writerow(self.model._headers)
                # 写入数据行
                writer.writerows(data)

            QMessageBox.information(self, "导出成功", f"数据已成功导出到：{file_path}")
        except Exception as e:
            QMessageBox.critical(self, "导出失败", f"写入CSV文件时出错：{str(e)}")

    def clear_table(self):
        """清空表格中的所有数据"""
        reply = QMessageBox.question(
            self, "确认清空",
            "确定要清空表格中的所有数据吗？此操作不可撤销。",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            self.model.load_data([])


def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()