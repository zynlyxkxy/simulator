import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.widgets import Cursor
import matplotlib.patches as mpatches
from matplotlib import rcParams

rcParams['font.family'] = 'SimHei'
rcParams['axes.unicode_minus'] = False   # 正常显示负号


class WaferChipVisualizer:
    def __init__(self, wafer_radius=100, chips_data=None):
        """
        初始化晶圆芯片可视化器

        参数:
        wafer_radius: 晶圆半径(mm)
        chips_data: 芯片数据列表，每个元素为字典，包含:
                   'x': 芯片中心x坐标
                   'y': 芯片中心y坐标
                   'width': 芯片宽度
                   'height': 芯片高度
                   'id': 芯片ID (可选)
                   'color': 芯片颜色 (可选)
        """
        self.wafer_radius = wafer_radius
        self.chips_data = chips_data if chips_data is not None else []

        # 创建图形和坐标轴
        self.fig, self.ax = plt.subplots(figsize=(10, 10))

        # 设置晶圆图标题
        self.ax.set_title(f'晶圆芯片分布图\n晶圆半径: {wafer_radius}mm, 芯片数: {len(self.chips_data)}',
                          fontsize=16, fontweight='bold')

        # 绘制晶圆
        self.draw_wafer()

        # 绘制芯片
        self.draw_chips()

        # 设置坐标轴属性
        self.setup_axes()

        # 添加图例
        self.add_legend()

        # 设置光标和悬停效果
        self.setup_interactivity()

    def draw_wafer(self):
        """绘制晶圆"""
        wafer = plt.Circle((0, 0), self.wafer_radius,
                           fill=True, color='lightblue', alpha=0.3,
                           edgecolor='blue', linewidth=2)
        self.ax.add_patch(wafer)

        # 绘制晶圆中心
        self.ax.scatter(0, 0, color='red', s=100, marker='+', linewidths=2, label='晶圆中心')

        # 绘制晶圆边缘
        theta = np.linspace(0, 2 * np.pi, 100)
        x_edge = self.wafer_radius * np.cos(theta)
        y_edge = self.wafer_radius * np.sin(theta)
        self.ax.plot(x_edge, y_edge, 'b-', linewidth=2, alpha=0.5)

    def draw_chips(self):
        """根据外部输入数据绘制芯片"""
        self.chips = []
        self.chip_patches = []

        for i, chip_info in enumerate(self.chips_data):
            # 从输入数据中提取芯片信息
            center_x = chip_info.get('x', 0)
            center_y = chip_info.get('y', 0)
            chip_width = chip_info.get('width', 10)
            chip_height = chip_info.get('height', 10)
            chip_id = chip_info.get('id', i + 1)
            chip_color = chip_info.get('color', 'green')

            # 计算芯片左下角坐标
            x = center_x - chip_width / 2
            y = center_y - chip_height / 2

            # 检查芯片是否在晶圆内
            distance_from_center = np.sqrt(center_x ** 2 + center_y ** 2)
            chip_radius = np.sqrt((chip_width / 2) ** 2 + (chip_height / 2) ** 2)

            # 如果芯片在晶圆内，则绘制
            if distance_from_center + chip_radius <= self.wafer_radius:
                # 创建矩形芯片
                chip = patches.Rectangle(
                    (x, y), chip_width, chip_height,
                    linewidth=1, edgecolor='black', facecolor=chip_color, alpha=0.7
                )

                # 添加到坐标轴
                self.ax.add_patch(chip)

                # 保存芯片信息
                chip_data = {
                    'id': chip_id,
                    'x': x,
                    'y': y,
                    'center_x': center_x,
                    'center_y': center_y,
                    'width': chip_width,
                    'height': chip_height,
                    'color': chip_color,
                    'patch': chip
                }

                self.chips.append(chip_data)
                self.chip_patches.append(chip)

                # 在芯片中心添加文本标签
                self.ax.text(center_x, center_y, str(chip_id),
                             ha='center', va='center', fontsize=8, color='white', fontweight='bold')
            else:
                print(f"警告: 芯片 {chip_id} 在晶圆外，将被忽略")

        # 更新实际绘制的芯片数量
        self.actual_chips = len(self.chips)
        print(f"晶圆上有效芯片数量: {self.actual_chips}/{len(self.chips_data)}")

    def setup_axes(self):
        """设置坐标轴属性"""
        self.ax.set_aspect('equal')
        self.ax.set_xlabel('X 坐标 (mm)', fontsize=12)
        self.ax.set_ylabel('Y 坐标 (mm)', fontsize=12)

        # 设置坐标轴范围
        margin = self.wafer_radius * 1.1
        self.ax.set_xlim(-margin, margin)
        self.ax.set_ylim(-margin, margin)

        # 添加网格
        self.ax.grid(True, linestyle='--', alpha=0.5)

    def add_legend(self):
        """添加图例"""
        # 创建自定义图例元素
        wafer_patch = mpatches.Patch(color='lightblue', alpha=0.3, label='晶圆')
        chip_patch = mpatches.Patch(color='green', alpha=0.7, label='芯片')
        center_marker = mpatches.Patch(color='red', alpha=1, label='晶圆中心')

        # 添加图例
        self.ax.legend(handles=[wafer_patch, chip_patch, center_marker],
                       loc='upper right', fontsize=10)

        # 添加芯片数量信息
        info_text = f'有效芯片数: {self.actual_chips}'
        self.ax.text(0.02, 0.98, info_text, transform=self.ax.transAxes,
                     fontsize=10, verticalalignment='top',
                     bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

    def setup_interactivity(self):
        """设置交互功能"""
        # 创建十字光标
        self.cursor = Cursor(self.ax, useblit=True, color='red', linewidth=1)

        # 创建用于显示芯片信息的文本框
        self.annotation = self.ax.annotate(
            "", xy=(0, 0), xytext=(20, 20),
            textcoords="offset points",
            bbox=dict(boxstyle="round", fc="yellow", alpha=0.9),
            arrowprops=dict(arrowstyle="->")
        )
        self.annotation.set_visible(False)

        # 连接鼠标移动事件
        self.fig.canvas.mpl_connect("motion_notify_event", self.on_hover)

    def on_hover(self, event):
        """鼠标悬停事件处理"""
        # 检查鼠标是否在图形区域内
        if event.inaxes != self.ax:
            self.annotation.set_visible(False)
            self.fig.canvas.draw_idle()
            return

        # 检查鼠标是否在某个芯片上
        chip_hovered = False
        for chip_info in self.chips:
            chip = chip_info['patch']
            contains, _ = chip.contains(event)
            if contains:
                # 更新注解文本
                text = f"芯片 ID: {chip_info['id']}\n"
                text += f"中心坐标: ({chip_info['center_x']:.2f}, {chip_info['center_y']:.2f})\n"
                text += f"左下角: ({chip_info['x']:.2f}, {chip_info['y']:.2f})\n"
                text += f"尺寸: {chip_info['width']}×{chip_info['height']} mm\n"
                text += f"颜色: {chip_info['color']}"

                self.annotation.xy = (event.xdata, event.ydata)
                self.annotation.set_text(text)
                self.annotation.set_visible(True)

                # 高亮显示当前芯片
                for c in self.chips:
                    c['patch'].set_alpha(0.3)
                chip.set_alpha(0.9)

                chip_hovered = True
                break

        # 如果鼠标不在任何芯片上，隐藏注解并恢复所有芯片的透明度
        if not chip_hovered:
            self.annotation.set_visible(False)
            for chip_info in self.chips:
                chip_info['patch'].set_alpha(0.7)

        self.fig.canvas.draw_idle()


def generate_sample_chips(wafer_radius=100, num_chips=50):
    """生成示例芯片数据"""
    chips = []

    for i in range(num_chips):
        # 在晶圆内随机生成芯片位置
        angle = np.random.uniform(0, 2 * np.pi)
        radius = np.random.uniform(0, wafer_radius * 0.8)

        center_x = radius * np.cos(angle)
        center_y = radius * np.sin(angle)

        # 随机生成芯片尺寸
        width = np.random.choice([8, 10, 12])
        height = np.random.choice([8, 10, 12])

        # 随机选择芯片颜色
        colors = ['green', 'blue', 'orange', 'purple', 'brown']
        color = np.random.choice(colors)

        chip_data = {
            'x': center_x,
            'y': center_y,
            'width': width,
            'height': height,
            'id': i + 1,
            'color': color
        }

        chips.append(chip_data)

    return chips


def load_chips_from_file(filename):
    """从文件加载芯片数据"""
    chips = []

    try:
        with open(filename, 'r') as f:
            lines = f.readlines()

        for line in lines:
            # 跳过注释行和空行
            if line.startswith('#') or line.strip() == '':
                continue

            # 假设每行格式: id,x,y,width,height,color
            parts = line.strip().split(',')

            if len(parts) >= 5:
                chip_data = {
                    'id': int(parts[0]),
                    'x': float(parts[1]),
                    'y': float(parts[2]),
                    'width': float(parts[3]),
                    'height': float(parts[4]),
                    'color': parts[5] if len(parts) > 5 else 'green'
                }
                chips.append(chip_data)

    except FileNotFoundError:
        print(f"文件 {filename} 未找到，将使用示例数据")
        chips = generate_sample_chips()

    return chips


def main():
    """主函数"""
    print("=" * 50)
    print("晶圆芯片位置可视化程序")
    print("=" * 50)

    # 晶圆参数
    wafer_radius = 100  # 晶圆半径(mm)

    # 从文件加载芯片数据或生成示例数据
    filename = "chips_data.txt"  # 可以修改为您的数据文件名

    # 从文件加载芯片数据
    chips_data = load_chips_from_file(filename)

    # 如果没有从文件加载到数据，则生成示例数据
    if not chips_data:
        print(f"未找到有效芯片数据，生成示例数据")
        chips_data = generate_sample_chips(wafer_radius=wafer_radius, num_chips=50)

    print(f"晶圆半径: {wafer_radius}mm")
    print(f"加载芯片数量: {len(chips_data)}")
    print("-" * 50)

    # 创建可视化器
    visualizer = WaferChipVisualizer(
        wafer_radius=wafer_radius,
        chips_data=chips_data
    )

    print("提示: 将鼠标悬停在芯片上查看详细信息")
    print("=" * 50)

    # 显示图形
    plt.tight_layout()
    plt.show()


def create_sample_data_file(filename="chips_data.txt"):
    """创建示例数据文件"""
    sample_data = """# 芯片数据文件格式: id,x,y,width,height,color
# x,y: 芯片中心坐标
# width,height: 芯片尺寸
# color: 芯片颜色 (可选)
1,20,30,10,10,green
2,-15,25,8,8,blue
3,10,-20,12,12,orange
4,-25,-15,10,10,purple
5,40,0,8,12,green
6,0,40,12,8,blue
7,-35,10,10,10,orange
8,15,-35,8,8,purple
9,30,25,12,12,green
10,-20,-30,10,10,blue
"""

    with open(filename, 'w') as f:
        f.write(sample_data)

    print(f"示例数据文件已创建: {filename}")


if __name__ == "__main__":
    # 创建示例数据文件（如果不存在）
    create_sample_data_file()

    # 运行主程序
    main()