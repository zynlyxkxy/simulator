import numpy as np
import pandas as pd
import EGA_fit


np.random.seed(24)
# 参数设置
wafer_radius = 12 * 25.4 / 2 - 3  # 12英寸晶圆减去3mm边缘
chip_width = 15  # 芯片宽度
chip_height = 8  # 芯片高度
spacing = 0.08  # 芯片间距
a = 4.35  # 标记点X偏移
b = 3.5  # 标记点Y偏移

cells_layout = EGA_fit.creat_chip_position(wafer_radius, chip_width, chip_height, spacing)
marks_layout = EGA_fit.compute_mark_positions(cells_layout, a, b)
#选取点进行对准
fit_points = EGA_fit.select_fitting_points(marks_layout, 6, wafer_radius)
#模拟对准结果
coarse_coords = EGA_fit.simulate_real_positions(fit_points, np.array([-125.2, 354.24, 0.98, 1.02, 0.0002, 0.00001]), noise_sigma=0.0005)
#开始拟合EGA的六参数
params = EGA_fit.ega_fit(fit_points, coarse_coords)
#将cells_layout转换为粗动台坐标系
cells_coarse_coords = EGA_fit.transform_layout_to_coarse_coords(cells_layout, params)
# print(f"cells_layout:{cells_layout[141:145]}\ncoarse_coords:{cells_coarse_coords[141:145]}")