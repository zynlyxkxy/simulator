import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import least_squares
import matplotlib


def creat_chip_position(wafer_radius, chip_width, chip_height, spacing):
    """创建晶圆上的芯片位置"""
    step_x = chip_width + spacing
    step_y = chip_height + spacing

    # 生成x坐标网格
    x_coords = np.arange(-wafer_radius + step_x / 2, wafer_radius, step_x)
    if len(x_coords[x_coords >= 0]) > 0:
        x_coords = x_coords - np.min(x_coords[x_coords >= 0])

    # 生成y坐标网格
    y_coords = np.arange(-wafer_radius + step_y / 2, wafer_radius, step_y)
    if len(y_coords[y_coords >= 0]) > 0:
        y_coords = y_coords - np.min(y_coords[y_coords >= 0])

    xv, yv = np.meshgrid(x_coords, y_coords)
    grid_positions = np.column_stack((xv.ravel(), yv.ravel()))

    # 计算芯片角点到中心的距离（用于边界检查）
    corner_distance = np.sqrt((chip_width / 2) ** 2 + (chip_height / 2) ** 2)

    # 过滤超出晶圆的芯片
    distances = np.sqrt(grid_positions[:, 0] ** 2 + grid_positions[:, 1] ** 2)
    nominal_positions = grid_positions[distances + corner_distance < wafer_radius]

    return nominal_positions


def compute_mark_positions(centers, a, b):
    """计算每个芯片的标记点位置"""
    offsets = np.array([
        [a, b],
        [a, -b],
        [-a, b],
        [-a, -b]
    ])
    marks = centers[:, None, :] + offsets[None, :, :]
    return marks.reshape(-1, 2)

def simulate_real_positions(nominal_positions, params, noise_sigma=0):
    real_positions = []
    for (u, v) in nominal_positions:
        x = params[0] + params[2] * u - (params[4] + params[5]) * v
        y = params[1] + params[3] * v + (params[4] + params[5]) * u
        real_positions.append((x, y))
    noise_real_positions = np.array(real_positions).copy()

    noise = np.random.normal(0, noise_sigma, noise_real_positions.shape)
    noise_real_positions += noise
    return noise_real_positions

def select_fitting_points(nominal_positions, points_number, wafer_radius):
    target_radius = wafer_radius * 0.8

    angles = np.linspace(0, 2 * np.pi, points_number, endpoint=False)
    fit_points = []
    for angle in angles:
        target_x = target_radius * np.cos(angle)
        target_y = target_radius * np.sin(angle)
        distances = np.sqrt(
            (nominal_positions[:, 0] - target_x) ** 2 +
            (nominal_positions[:, 1] - target_y) ** 2
        )
        closest_point_index = np.argmin(distances)
        fit_points.append(nominal_positions[closest_point_index])
    return np.array(fit_points)

def ega_fit(fit_points, real_points):
    def resduals(params, fit_points, real_points):
        estimated = []
        for (u, v) in fit_points:
            x = params[0] + params[2] * u - (params[4] + params[5]) * v
            y = params[1] + params[3] * v + (params[4] + params[5]) * u
            estimated.append((x, y))
        estimated = np.array(estimated)
        return (estimated - real_points).ravel()

    intial_params = [0, 0, 1, 1, 0, 0]
    result = least_squares(resduals, intial_params, args=(fit_points, real_points))
    return result.x

def transform_layout_to_coarse_coords(nominal_points, params):
    coarse_coords = []
    for (u, v) in nominal_points:
        x = params[0] + params[2] * u - (params[4] + params[5]) * v
        y = params[1] + params[3] * v + (params[4] + params[5]) * u
        coarse_coords.append((x, y))
    return np.array(coarse_coords)