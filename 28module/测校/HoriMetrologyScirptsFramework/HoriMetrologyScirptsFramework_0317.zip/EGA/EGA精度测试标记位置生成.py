import numpy as np


def creat_chip_position(wafer_radius, chip_width, chip_height, spacing):
    """创建晶圆上的芯片位置"""
    step_x = chip_width + spacing
    step_y = chip_height + spacing

    # 生成x坐标网格
    x_coords = np.arange(-wafer_radius + step_x / 2, wafer_radius, step_x)
    if len(x_coords[x_coords >= 0]) > 0:
        x_coords = x_coords - np.min(x_coords[x_coords >= 0])

    # 生成y坐标网格
    y_coords = np.arange(-wafer_radius + step_y / 2, wafer_radius, step_y)
    if len(y_coords[y_coords >= 0]) > 0:
        y_coords = y_coords - np.min(y_coords[y_coords >= 0])

    xv, yv = np.meshgrid(x_coords, y_coords)
    grid_positions = np.column_stack((xv.ravel(), yv.ravel()))

    # 计算芯片角点到中心的距离（用于边界检查）
    corner_distance = np.sqrt((chip_width / 2) ** 2 + (chip_height / 2) ** 2)

    # 过滤超出晶圆的芯片
    distances = np.sqrt(grid_positions[:, 0] ** 2 + grid_positions[:, 1] ** 2)
    nominal_positions = grid_positions[distances + corner_distance < wafer_radius]

    return nominal_positions


def compute_mark_positions(centers, a, b):
    """计算每个芯片的标记点位置"""
    offsets = np.array([
        [a, b],
        [a, -b],
        [-a, b],
        [-a, -b]
    ])
    marks = centers[:, None, :] + offsets[None, :, :]
    return marks.reshape(-1, 2)

def nominal_to_real(nominal, params):
    real_positions = []
    for (u, v) in nominal:
        x = params[0] + params[2] * u - (params[4] + params[5]) * v
        y = params[1] + params[3] * v + (params[4] - params[5]) * u
        real_positions.append((x, y))
    return np.array(real_positions)

# 参数设置
wafer_radius = 12 * 25.4 / 2 - 3  # 12英寸晶圆减去3mm边缘
chip_width = 10  # 芯片宽度
chip_height = 10  # 芯片高度
spacing = 0.08  # 芯片间距
a = 3.8  # 标记点X偏移
b = 0  # 标记点Y偏移
params = np.array([-48.7768, -189.474, 0.999977, 1, 0.00150518, 4.41274e-5])

cells_layout = creat_chip_position(wafer_radius, chip_width, chip_height, spacing)
marks_layout = compute_mark_positions(cells_layout, a, b)
real_position = nominal_to_real(marks_layout, params)
# print(real_position)