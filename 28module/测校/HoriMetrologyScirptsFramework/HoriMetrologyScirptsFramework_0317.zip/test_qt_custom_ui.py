# -*- coding: utf-8 -*-
import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel
from qt_custom_ui import create_spinbox, create_combobox

if __name__ == "__main__":
    try:
        app = QApplication(sys.argv)
        app.setStyle("Fusion")
        window = QWidget()
        window.setWindowTitle("Test qt_custom_ui")
        window.resize(400, 200)
        
        main_layout = QVBoxLayout(window)
        
        # 测试spinbox
        spinbox_layout = QHBoxLayout()
        spinbox_label = QLabel("Test SpinBox:")
        spinbox = create_spinbox(0, 100, 2)
        spinbox.setValue(50.5)
        spinbox_layout.addWidget(spinbox_label)
        spinbox_layout.addWidget(spinbox)
        main_layout.addLayout(spinbox_layout)
        
        # 测试combobox
        combobox_layout = QHBoxLayout()
        combobox_label = QLabel("Test ComboBox:")
        combobox = create_combobox(["Option 1", "Option 2", "Option 3"])
        combobox_layout.addWidget(combobox_label)
        combobox_layout.addWidget(combobox)
        main_layout.addLayout(combobox_layout)
        
        print("qt_custom_ui components created successfully!")
        print("SpinBox style updated:", hasattr(spinbox, 'styleSheet'))
        print("ComboBox style updated:", hasattr(combobox, 'styleSheet'))
        
        # 不显示窗口，只验证组件创建
        # window.show()
        # sys.exit(app.exec_())
    except Exception as e:
        print(f"Error testing qt_custom_ui: {e}")
        import traceback
        traceback.print_exc()
