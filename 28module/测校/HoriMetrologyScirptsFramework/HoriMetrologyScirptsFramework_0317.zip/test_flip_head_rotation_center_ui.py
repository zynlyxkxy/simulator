#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试FlipHeadRotationCenter_ui.py的UI加载
"""

import sys
import os

# 添加当前目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from PyQt5.QtWidgets import QApplication
from FlipHeadRotationCenter_ui import Ui_Widget


def test_flip_head_rotation_center_ui():
    """测试FlipHeadRotationCenter UI加载"""
    print("测试FlipHeadRotationCenter UI加载...")
    
    app = QApplication(sys.argv)
    
    # 创建主窗口
    widget = Ui_Widget()
    widget.setupUi(widget)
    
    # 显示窗口
    widget.show()
    
    # 运行应用
    print("FlipHeadRotationCenter UI加载成功！")
    print("窗口已显示，按Ctrl+C退出测试")
    
    try:
        sys.exit(app.exec_())
    except KeyboardInterrupt:
        print("测试结束")


if __name__ == "__main__":
    test_flip_head_rotation_center_ui()
